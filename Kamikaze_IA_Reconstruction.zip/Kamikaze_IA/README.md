# Kamikaze IA — projet prêt à configurer

Plateforme web responsive avec trois modules :
- génération d'images via fal.ai ;
- génération de vidéos via fal.ai ;
- assistant conversationnel via l'API OpenAI.

## 1. Préparation

Prérequis : Node.js 20 ou plus récent.

```bash
npm install
cp .env.example .env
```

Ouvrez `.env` et ajoutez vos clés :
- `FAL_KEY` : clé fal.ai pour les générations d'images et de vidéos ;
- `OPENAI_API_KEY` : clé OpenAI pour l'assistant.

Les clés sont lues uniquement par le serveur. Elles ne sont jamais envoyées au navigateur.

## 2. Lancer en local

```bash
npm start
```

Puis ouvrez http://localhost:3000

## 3. Déployer sur Render

1. Créez un dépôt GitHub et téléversez le contenu de ce dossier.
2. Dans Render, choisissez **New + > Blueprint** et sélectionnez le dépôt.
3. Render détectera `render.yaml`.
4. Dans les variables d'environnement du service, entrez `FAL_KEY` et `OPENAI_API_KEY`.
5. Lancez le déploiement puis ouvrez l'URL Render.

Vous pouvez aussi créer un **Web Service** directement avec :
- Build command : `npm install`
- Start command : `npm start`
- Health check path : `/api/health`

## 4. Choisir les modèles

Les modèles sont configurables dans les variables d'environnement :
- `FAL_IMAGE_MODEL` (défaut : `fal-ai/flux/dev`)
- `FAL_VIDEO_MODEL` (défaut : `fal-ai/kling-video/v2.1/standard`)
- `OPENAI_MODEL` (défaut : `gpt-4o-mini`)

Vérifiez dans votre compte fal.ai que les modèles choisis sont disponibles et que votre clé y a accès. Les fournisseurs peuvent modifier les identifiants, paramètres, prix et conditions des modèles. Adaptez au besoin les champs `input` dans `server.js` au schéma du modèle choisi.

## Important avant la vente

Ce ZIP est une base fonctionnelle d'intégration, pas un produit commercial final certifié. Les appels réels nécessitent des clés valides, des crédits/facturation chez les fournisseurs et la validation des modèles. Avant de vendre l'application 399 $, ajoutez notamment : authentification, gestion des utilisateurs, quotas/crédits, protection contre l'abus, journalisation, politique de confidentialité, conditions d'utilisation, paiements et tests de charge. Ne promettez pas de générations illimitées sans calculer les coûts réels.
