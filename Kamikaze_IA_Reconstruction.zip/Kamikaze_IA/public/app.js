const $ = (id) => document.getElementById(id);
$("year").textContent = new Date().getFullYear();

document.querySelectorAll(".tab").forEach((tab) => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach((x) => x.classList.toggle("active", x === tab));
    document.querySelectorAll(".panel").forEach((x) => x.classList.toggle("active", x.id === `panel-${tab.dataset.tab}`));
  });
});

async function api(path, body) {
  const response = await fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `Erreur ${response.status}`);
  return data;
}

function setBusy(button, busy, label) {
  button.disabled = busy;
  if (busy) { button.dataset.original = button.innerHTML; button.textContent = label; }
  else if (button.dataset.original) button.innerHTML = button.dataset.original;
}

function findMedia(value, depth = 0) {
  if (!value || depth > 7) return null;
  if (typeof value === "string" && /^https?:\/\//i.test(value)) {
    if (/\.(png|jpe?g|webp|gif|mp4|webm)(\?|$)/i.test(value)) return value;
    return null;
  }
  if (Array.isArray(value)) {
    for (const item of value) { const found = findMedia(item, depth + 1); if (found) return found; }
  } else if (typeof value === "object") {
    for (const [key, item] of Object.entries(value)) {
      if (["url", "video_url", "image_url"].includes(key) && typeof item === "string" && /^https?:\/\//i.test(item)) return item;
    }
    for (const item of Object.values(value)) { const found = findMedia(item, depth + 1); if (found) return found; }
  }
  return null;
}

$("makeImage").addEventListener("click", async () => {
  const button = $("makeImage"), prompt = $("imagePrompt").value.trim(), target = $("imageResult");
  if (!prompt) return alert("Écris une description avant de générer.");
  setBusy(button, true, "Création en cours…");
  target.textContent = "Le moteur IA travaille sur ton image…";
  try {
    const data = await api("/api/image", { prompt });
    const url = findMedia(data.result);
    if (!url) { target.textContent = "Résultat reçu, mais aucun lien d'image reconnu. Consulte les détails du modèle dans les journaux serveur."; }
    else { target.innerHTML = ""; const img = document.createElement("img"); img.src = url; img.alt = "Image générée par Kamikaze IA"; target.append(img); }
  } catch (e) { target.textContent = e.message; }
  finally { setBusy(button, false); }
});

$("makeVideo").addEventListener("click", async () => {
  const button = $("makeVideo"), prompt = $("videoPrompt").value.trim(), target = $("videoResult");
  if (!prompt) return alert("Écris une description avant de générer.");
  setBusy(button, true, "Création en cours…");
  target.textContent = "La vidéo peut prendre quelques minutes…";
  try {
    const data = await api("/api/video", { prompt });
    const url = findMedia(data.result);
    if (!url) { target.textContent = "Résultat reçu, mais aucun lien vidéo reconnu. Consulte les journaux serveur."; }
    else {
      target.innerHTML = "";
      const video = document.createElement("video"); video.src = url; video.controls = true; video.playsInline = true;
      target.append(video);
    }
  } catch (e) { target.textContent = e.message; }
  finally { setBusy(button, false); }
});

function addBubble(text, type) {
  const bubble = document.createElement("div");
  bubble.className = `bubble ${type}`;
  bubble.textContent = text;
  $("chatWindow").append(bubble);
  $("chatWindow").scrollTop = $("chatWindow").scrollHeight;
}

async function sendChat() {
  const button = $("sendChat"), input = $("chatPrompt"), message = input.value.trim();
  if (!message) return;
  addBubble(message, "user"); input.value = "";
  setBusy(button, true, "…");
  try {
    const data = await api("/api/chat", { message });
    addBubble(data.answer || "Aucune réponse.", "assistant");
  } catch (e) { addBubble(e.message, "assistant"); }
  finally { setBusy(button, false); }
}
$("sendChat").addEventListener("click", sendChat);
$("chatPrompt").addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendChat(); } });

fetch("/api/health").then(r => r.json()).then(s => {
  const ready = s.imageConfigured && s.videoConfigured && s.assistantConfigured;
  $("statusText").textContent = ready ? "Moteurs configurés" : "Configuration requise";
  document.querySelector(".status i").style.background = ready ? "#43e6a2" : "#e7b34b";
}).catch(() => $("statusText").textContent = "Serveur non connecté");
