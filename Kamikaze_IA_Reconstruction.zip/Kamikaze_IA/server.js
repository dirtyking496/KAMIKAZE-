import "dotenv/config";
import express from "express";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { fal } from "@fal-ai/client";
import OpenAI from "openai";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: "2mb" }));
app.use(express.static(path.join(__dirname, "public")));

if (process.env.FAL_KEY) {
  fal.config({ credentials: process.env.FAL_KEY });
}

const imageModel = process.env.FAL_IMAGE_MODEL || "fal-ai/flux/dev";
const videoModel = process.env.FAL_VIDEO_MODEL || "fal-ai/kling-video/v2.1/standard";
const openai = process.env.OPENAI_API_KEY
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

app.get("/api/health", (_req, res) => {
  res.json({
    ok: true,
    imageConfigured: Boolean(process.env.FAL_KEY),
    videoConfigured: Boolean(process.env.FAL_KEY),
    assistantConfigured: Boolean(openai),
  });
});

function requireFal(res) {
  if (!process.env.FAL_KEY) {
    res.status(503).json({
      error: "Le moteur fal.ai n'est pas configuré. Ajoutez FAL_KEY dans les variables d'environnement."
    });
    return false;
  }
  return true;
}

app.post("/api/image", async (req, res) => {
  if (!requireFal(res)) return;
  const prompt = String(req.body?.prompt || "").trim();
  if (prompt.length < 3 || prompt.length > 2000) {
    return res.status(400).json({ error: "Décrivez l'image (3 à 2000 caractères)." });
  }
  try {
    const result = await fal.subscribe(imageModel, {
      input: { prompt, image_size: "landscape_4_3", num_images: 1 }
    });
    res.json({ ok: true, result });
  } catch (error) {
    console.error("Image generation error:", error);
    res.status(502).json({ error: error?.message || "La génération d'image a échoué." });
  }
});

app.post("/api/video", async (req, res) => {
  if (!requireFal(res)) return;
  const prompt = String(req.body?.prompt || "").trim();
  if (prompt.length < 3 || prompt.length > 2000) {
    return res.status(400).json({ error: "Décrivez la vidéo (3 à 2000 caractères)." });
  }
  try {
    const result = await fal.subscribe(videoModel, {
      input: { prompt, duration: "5" }
    });
    res.json({ ok: true, result });
  } catch (error) {
    console.error("Video generation error:", error);
    res.status(502).json({ error: error?.message || "La génération vidéo a échoué." });
  }
});

app.post("/api/chat", async (req, res) => {
  if (!openai) {
    return res.status(503).json({
      error: "L'assistant n'est pas configuré. Ajoutez OPENAI_API_KEY dans les variables d'environnement."
    });
  }
  const message = String(req.body?.message || "").trim();
  if (message.length < 1 || message.length > 8000) {
    return res.status(400).json({ error: "Écrivez un message (maximum 8000 caractères)." });
  }
  try {
    const completion = await openai.chat.completions.create({
      model: process.env.OPENAI_MODEL || "gpt-4o-mini",
      messages: [
        { role: "system", content: "Tu es Kamikaze IA, un assistant utile, clair et créatif. Réponds en français par défaut." },
        { role: "user", content: message }
      ],
      temperature: 0.7
    });
    res.json({ ok: true, answer: completion.choices?.[0]?.message?.content || "Aucune réponse reçue." });
  } catch (error) {
    console.error("Assistant error:", error);
    res.status(502).json({ error: error?.message || "L'assistant IA n'a pas pu répondre." });
  }
});

app.get("*", (_req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => console.log(`Kamikaze IA prêt sur le port ${PORT}`));
